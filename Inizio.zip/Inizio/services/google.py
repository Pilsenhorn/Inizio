import requests

def get_google_results(query: str):
    response = requests.get(
        "https://serpapi.com/search.json",
        params={
            "q": query,
            "google_domain": "google.com",
            "api_key": "YOUR_SERPAPI_KEY"
        }
    )
    data = response.json()
    print(data)
    results = data.get("organic_results", [])
    clean_results = []
    for item in results[:11]: # limit na 10 výsledků
        clean_results.append({
            "title": item.get("title"),
            "link": item.get("link"),
            "snippet": item.get("snippet")
        })
    return clean_results



