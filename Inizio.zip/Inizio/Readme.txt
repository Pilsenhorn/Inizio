1. vytvoř si účet na serpapi.com
2. nastav API key:
   Windows:
   set SERPAPI_KEY=tvuj_klic

   Mac/Linux:
   export SERPAPI_KEY=tvuj_klic

3. spusť:
   uvicorn main:app --reload